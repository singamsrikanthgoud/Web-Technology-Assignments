# Hotel Management System
The project, Hotel Management System is a desktop-based application that allows the hotel manager to handle all hotel activities online. Interactive GUI and the ability to manage various rooms, employees, drivers and customers make this system very flexible and convenient. The hotel manager is a very busy person and does not have the time to sit and manage the entire activities manually on paper. This application gives him the power and flexibility to manage the entire system from a single online system. Hotel management project provides room booking, staff management and other necessary hotel management features. The system allows the manager to post available rooms in the system.


• Add a new Room \
• Add an Employee \
• Add a new Customer \
• Check room status \
• Check all employees’ details \
• Check all Customers’ details \
• Update room status \
• Update check status etc.
